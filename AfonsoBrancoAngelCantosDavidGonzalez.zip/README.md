# IA-Afonso-Angel-David-P2
 This is the second exercise for the IA class in the FIB-UPC

# How To Open
**On ClipsIDE**
 - Control + Shift + L
    - Select "run.bat"

**On ClipsCMD**
 - clips -f2 run.bat